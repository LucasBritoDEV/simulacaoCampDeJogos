public class Estadio extends EntidadeComNome{
    public String Endereco;
    public Time   Time;

    public Estadio(String nome, String endereco){
        this.Nome     = nome;
        this.Endereco = endereco;
    }
}