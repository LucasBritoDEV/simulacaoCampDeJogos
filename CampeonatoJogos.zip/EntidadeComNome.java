public abstract class EntidadeComNome extends Entidade{
    public String Nome;
}