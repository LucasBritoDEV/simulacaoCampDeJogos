public abstract class Entidade{
    public int Id;
}